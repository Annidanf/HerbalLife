package com.example.herballife;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailTileActivity extends AppCompatActivity {
    public static final String EXTRA_POSITION = "position";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tile);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // Set Collapsing Toolbar layout to the screen
        CollapsingToolbarLayout collapsingToolbar =
                (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        // Set title of Detail page
        collapsingToolbar.setTitle(getString(R.string.item_title));

        int postion = getIntent().getIntExtra(EXTRA_POSITION, 0);
        Resources resources = getResources();
        //places
        String[] tanaman = resources.getStringArray(R.array.tanaman);
        collapsingToolbar.setTitle(tanaman[postion % tanaman.length]);


        //places
        String[] tanamanDetails = resources.getStringArray(R.array.tanaman_detail);
        TextView placeDetail = (TextView) findViewById(R.id.tanaman_detail);
        placeDetail.setText(tanamanDetails[postion % tanamanDetails.length]);


        //places
        String[] tanamanLocations = resources.getStringArray(R.array.tanaman_locations);
        TextView placeLocation =  (TextView) findViewById(R.id.place_location);
        placeLocation.setText(tanamanLocations[postion % tanamanLocations.length]);

        //places
        TypedArray tanamanPictures = resources.obtainTypedArray(R.array.tanaman_picture);
        ImageView placePicutre = (ImageView) findViewById(R.id.image);
        placePicutre.setImageDrawable(tanamanPictures.getDrawable(postion % tanamanPictures.length()));


        tanamanPictures.recycle();
    }
}
