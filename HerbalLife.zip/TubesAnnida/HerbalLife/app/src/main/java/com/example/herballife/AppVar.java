package com.example.herballife;

public class AppVar {
    //URL to our login.php file, url bisa diganti sesuai dengan alamat server
    public static final String LOGIN_URL = "http://192.168.43.132/nida/login.php";

    //Keys for email and password as defined in our $_POST['key'] in login.php
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PASSWORD = "password";

    //if server response is equal to this that means login is succesfull
    public static final String LOGIN_SUCCESS = "success";
}
