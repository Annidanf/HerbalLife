package com.example.herballife;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class TipsHidupSehatFragment extends Fragment {
    //PERCOBAAN
    //Constructor
    public TipsHidupSehatFragment(){

    }
    //BUKAN PERCOBAAN
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        RecyclerView recyclerView = (RecyclerView) inflater.inflate(
                R.layout.recycler_view, container, false);
       TipsHidupSehatFragment.ContentAdapter adapter = new TipsHidupSehatFragment.ContentAdapter(recyclerView.getContext());
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
        // Set padding for Tiles
        int tilePadding = getResources().getDimensionPixelSize(R.dimen.tile_padding);
        recyclerView.setPadding(tilePadding, tilePadding, tilePadding, tilePadding);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        return recyclerView;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView picture;
        public TextView name;
        public ViewHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.item_hidupsehat, parent, false));
            picture = (ImageView) itemView.findViewById(R.id.hidup_picture);
            name = (TextView) itemView.findViewById(R.id.hidup_title);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Context context = v.getContext();
                    Intent intent = new Intent(context, DetailHidupActivity.class);
                    intent.putExtra(DetailHidupActivity.EXTRA_POSITION, getAdapterPosition());
                    context.startActivity(intent);
                }
            });
        }
    }

    /**
     * Adapter to display recycler view.
     */
    public static class ContentAdapter extends RecyclerView.Adapter<TipsHidupSehatFragment.ViewHolder> {
        // Set numbers of Tiles in RecyclerView.
        private static final int LENGTH = 4;

        private final String[] mHidup;
        private final Drawable[] mHidupPicture;
        public ContentAdapter(Context context) {
            Resources resources = context.getResources();
            mHidup = resources.getStringArray(R.array.hidup);
            TypedArray a = resources.obtainTypedArray(R.array.hidup_picture);
            mHidupPicture = new Drawable[a.length()];
            for (int i = 0; i <  mHidupPicture.length; i++) {
                mHidupPicture[i] = a.getDrawable(i);
            }
            a.recycle();
        }

        @Override
        public TipsHidupSehatFragment.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new TipsHidupSehatFragment.ViewHolder(LayoutInflater.from(parent.getContext()), parent);
        }

        @Override
        public void onBindViewHolder(TipsHidupSehatFragment.ViewHolder holder, int position) {
            holder.picture.setImageDrawable( mHidupPicture[position %  mHidupPicture.length]);
            holder.name.setText(mHidup[position % mHidup.length]);
        }

        @Override
        public int getItemCount() {
            return LENGTH;
        }
    }
}
