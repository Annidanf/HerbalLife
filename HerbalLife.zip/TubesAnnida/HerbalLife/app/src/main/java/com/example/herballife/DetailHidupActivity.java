package com.example.herballife;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailHidupActivity extends AppCompatActivity {

    public static final String EXTRA_POSITION = "position";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_hidup);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // Set Collapsing Toolbar layout to the screen
        CollapsingToolbarLayout collapsingToolbar =
                (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        // Set title of Detail page
        collapsingToolbar.setTitle(getString(R.string.item_title));

        int postion = getIntent().getIntExtra(EXTRA_POSITION, 0);
        Resources resources = getResources();
        //places
        String[] hidup = resources.getStringArray(R.array.hidup);
        collapsingToolbar.setTitle(hidup[postion % hidup.length]);


        //places
        String[] hidupDetails = resources.getStringArray(R.array.hidup_detail);
        TextView placeDetail = (TextView) findViewById(R.id.place_detail);
        placeDetail.setText(hidupDetails[postion % hidupDetails.length]);


        //places
        String[] hidupLocations = resources.getStringArray(R.array.hidup_locations);
        TextView placeLocation =  (TextView) findViewById(R.id.hidup_location);
        placeLocation.setText(hidupLocations[postion % hidupLocations.length]);

        //places
        TypedArray hidupPictures = resources.obtainTypedArray(R.array.hidup_picture);
        ImageView placePicutre = (ImageView) findViewById(R.id.image);
        placePicutre.setImageDrawable(hidupPictures.getDrawable(postion % hidupPictures.length()));


        hidupPictures.recycle();
    }
}
