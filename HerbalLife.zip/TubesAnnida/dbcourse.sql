-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 30, 2019 at 06:29 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbcourse`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(4) NOT NULL,
  `password` varchar(64) NOT NULL,
  `email` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `password`, `email`) VALUES
(1, 'annida', 'nurfadilahannida@gmail.com'),
(0, '$2y$10$6fo8kWd.mhc1ZPg.A8ZDyuH7.N1V2NkUnzYos0rUxEKCdeqzSBVxu', 'nida'),
(0, '$2y$10$iM/NwImc9Cd59i.tluuaReNfNUAX3L0gb/.iekzjvrBHUSdbYq8Py', 'nida'),
(0, '$2y$10$3lxSM/Eip/Slu1dPfWXPaeEHcN//4v8JwRt/D4bzTj6Ians.yFssa', 'nida'),
(0, '$2y$10$rKXONbSUJ5dmJVvy3XJxnu2BiaiFBOTkOux2ei.jy.XXUy5LTt7FW', 'nida'),
(0, '$2y$10$Lhcq.ud1wthwYRv2fNVBu.gTphVKZfKmaOIKZD2o1fOP4uQ4kpKE6', 'nurfadilahannida@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
