<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	

	$password = password_hash($password, PASSWORD_DEFAULT);

	require_once 'connect.php';

	$sql = "INSERT INTO users ( password, email) VALUES ('$password','$email')";

	if (mysqli_query ($con, $sql)) {
		$result["success"] = "1";
		$result["message"] = "success" ;

		echo json_encode($result);
		mysqli_close($con);
		# code...
	} else {
		$result["success"] = "0";
		$result["message"] = "error";

		echo json_encode($result);
		mysqli_close($con);
	}
	# code...
}
?>