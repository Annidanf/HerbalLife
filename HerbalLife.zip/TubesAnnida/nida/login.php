<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB' , 'dbcourse');

$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
if ($_SERVER ['REQUEST_METHOD']=='POST') {
	//Getting values
	$username = $_POST['email'];
	$password = $_POST['password'];

	//creating sql query
	$sql = "SELECT * FROM users WHERE email='$username' AND password='$password'";

	//executing query
	$result = mysqli_query($con,$sql);

	//fetching result
	$check = mysqli_fetch_array($result);

	//if we got some result
	if (isset($check)) {
		echo "success";
	}else{
		echo "failure";
	}
	mysqli_close($con);
}
?>